#pragma once
#include <lvgl.h>
#ifdef __cplusplus
extern "C" {
#endif
extern const lv_img_dsc_t ic_clock;  /* 52x52 */
extern const lv_img_dsc_t ic_imu;  /* 52x52 */
extern const lv_img_dsc_t ic_wifi;  /* 52x52 */
extern const lv_img_dsc_t ic_sd;  /* 52x52 */
extern const lv_img_dsc_t ic_audio;  /* 52x52 */
extern const lv_img_dsc_t ic_system;  /* 52x52 */
extern const lv_img_dsc_t img_emblem;  /* 104x104 */
extern const lv_img_dsc_t img_wordmark;  /* 224x45 */
#ifdef __cplusplus
}
#endif
