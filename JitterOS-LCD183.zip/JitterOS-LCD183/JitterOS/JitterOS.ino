/*
  JitterOS for Waveshare ESP32-S3-Touch-LCD-1.83 (240x284, ST7789P + CST816D)
  Hardware glue only - all UI lives in jitter_ui.cpp (pure LVGL 8.4).
  Based on Waveshare's 09_LVGL_Arduino example (same pins, drivers, touch handling).

  Arduino IDE: board "ESP32S3 Dev Module", USB CDC On Boot = Enabled, PSRAM = OPI PSRAM, Flash 16MB.
  Libraries: use the ones bundled in the Waveshare repo (examples/arduino/libraries) and replace
  that folder's lv_conf.h with the lv_conf.h from this project (see README).
*/
#include <lvgl.h>
#include "Arduino_GFX_Library.h"
#include "Arduino_DriveBus_Library.h"
#include "pin_config.h"
#include <Wire.h>
#include <WiFi.h>
#include "SensorQMI8658.hpp"
#include "SensorPCF85063.hpp"
#include "jitter_ui.h"

// Optional: battery readout on the home screen. Install "XPowersLib" to enable it.
#if __has_include(<XPowersLib.h>)
#include <XPowersLib.h>
#define JITTER_HAS_PMU 1
static XPowersPMU PMU;
static bool pmu_ok = false;
#else
#define JITTER_HAS_PMU 0
#endif

// ---- display + touch (identical to the Waveshare example) ------------------------
Arduino_DataBus *bus = new Arduino_ESP32SPI(LCD_DC, LCD_CS, LCD_SCK, LCD_MOSI);
Arduino_GFX *gfx = new Arduino_ST7789(bus, LCD_RST, 0 /* rotation */, true /* IPS */, LCD_WIDTH, LCD_HEIGHT, 0, 0, 0, 0);

std::shared_ptr<Arduino_IIC_DriveBus> IIC_Bus = std::make_shared<Arduino_HWIIC>(IIC_SDA, IIC_SCL, &Wire);
void Arduino_IIC_Touch_Interrupt(void);
std::unique_ptr<Arduino_IIC> CST816T(new Arduino_CST816x(IIC_Bus, CST816T_DEVICE_ADDRESS, TP_RST, TP_INT, Arduino_IIC_Touch_Interrupt));
void Arduino_IIC_Touch_Interrupt(void) { CST816T->IIC_Interrupt_Flag = true; }

static const uint32_t TOUCH_HOLD_MS = 80;
static int32_t lastTouchX, lastTouchY;
static uint32_t lastTouchMillis;
static bool lastTouchValid;

static bool readTouchPoint(int32_t *x, int32_t *y) {
  if (CST816T->IIC_Interrupt_Flag) {
    CST816T->IIC_Interrupt_Flag = false;
    int32_t tx = CST816T->IIC_Read_Device_Value(CST816T->Arduino_IIC_Touch::Value_Information::TOUCH_COORDINATE_X);
    int32_t ty = CST816T->IIC_Read_Device_Value(CST816T->Arduino_IIC_Touch::Value_Information::TOUCH_COORDINATE_Y);
    if (tx >= 0 && tx < LCD_WIDTH && ty >= 0 && ty < LCD_HEIGHT) {
      lastTouchX = tx; lastTouchY = ty; lastTouchMillis = millis(); lastTouchValid = true;
    }
  }
  if (!lastTouchValid || millis() - lastTouchMillis > TOUCH_HOLD_MS) { lastTouchValid = false; return false; }
  *x = lastTouchX; *y = lastTouchY;
  return true;
}

// ---- LVGL glue ----------------------------------------------------------------------
static lv_disp_draw_buf_t draw_buf;
static void my_disp_flush(lv_disp_drv_t *disp, const lv_area_t *area, lv_color_t *color_p) {
  uint32_t w = area->x2 - area->x1 + 1, h = area->y2 - area->y1 + 1;
#if (LV_COLOR_16_SWAP != 0)
  gfx->draw16bitBeRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#else
  gfx->draw16bitRGBBitmap(area->x1, area->y1, (uint16_t *)&color_p->full, w, h);
#endif
  lv_disp_flush_ready(disp);
}
static void my_touchpad_read(lv_indev_drv_t *drv, lv_indev_data_t *data) {
  int32_t x, y;
  if (readTouchPoint(&x, &y)) { data->state = LV_INDEV_STATE_PR; data->point.x = x; data->point.y = y; }
  else data->state = LV_INDEV_STATE_REL;
}
static void lvgl_tick(void *arg) { lv_tick_inc(2); }

// ---- peripherals ----------------------------------------------------------------------
SensorQMI8658 qmi;
SensorPCF85063 rtc;
static bool imu_ok = false, rtc_ok = false;

static int wifi_scan(char ssid[][33], int *rssi, int max) {
  WiFi.mode(WIFI_STA);
  WiFi.disconnect();
  int n = WiFi.scanNetworks();
  if (n < 0) n = 0;
  if (n > max) n = max;
  for (int i = 0; i < n; i++) {
    strncpy(ssid[i], WiFi.SSID(i).c_str(), 32);
    ssid[i][32] = 0;
    rssi[i] = WiFi.RSSI(i);
  }
  WiFi.scanDelete();
  return n;
}

static void sys_text(char *buf, size_t len) {
  uint32_t s = millis() / 1000;
  char batt[12] = "n/a";
#if JITTER_HAS_PMU
  if (pmu_ok && PMU.isBatteryConnect()) snprintf(batt, sizeof batt, "%d%%", PMU.getBatteryPercent());
#endif
  snprintf(buf, len, "CHIP  %s\nCPU   %u MHz\nHEAP  %u KB\nPSRAM %.1f MB\nUP    %02u:%02u:%02u\nBATT  %s",
           ESP.getChipModel(), (unsigned)ESP.getCpuFreqMHz(), (unsigned)(ESP.getFreeHeap() / 1024),
           ESP.getPsramSize() / 1048576.0, (unsigned)(s / 3600), (unsigned)((s / 60) % 60), (unsigned)(s % 60), batt);
}

// Build time from __DATE__/__TIME__, used only if the RTC has never been set
static void rtc_set_from_build() {
  static const char *mn = "JanFebMarAprMayJunJulAugSepOctNovDec";
  char m[4]; int d, y, hh, mm, ss;
  sscanf(__DATE__, "%3s %d %d", m, &d, &y);
  sscanf(__TIME__, "%d:%d:%d", &hh, &mm, &ss);
  int mon = (strstr(mn, m) - mn) / 3 + 1;
  rtc.setDateTime(y, mon, d, hh, mm, ss);
}

void setup() {
  Wire.begin(IIC_SDA, IIC_SCL);

  while (CST816T->begin() == false) delay(500);
  CST816T->IIC_Write_Device_State(CST816T->Arduino_IIC_Touch::Device::TOUCH_DEVICE_INTERRUPT_MODE,
                                  CST816T->Arduino_IIC_Touch::Device_Mode::TOUCH_DEVICE_INTERRUPT_PERIODIC);
  gfx->begin();
  gfx->fillScreen(BLACK);  // no white flash before the boot splash
  pinMode(LCD_BL, OUTPUT);
  digitalWrite(LCD_BL, HIGH);

  rtc_ok = rtc.begin(Wire, PCF85063_SLAVE_ADDRESS, IIC_SDA, IIC_SCL);
  if (rtc_ok) {
    RTC_DateTime dt = rtc.getDateTime();
    if (dt.year < 2024 || dt.year > 2099) rtc_set_from_build();
  }
  imu_ok = qmi.begin(Wire, QMI8658_L_SLAVE_ADDRESS, IIC_SDA, IIC_SCL);
  if (imu_ok) {
    qmi.configAccelerometer(SensorQMI8658::ACC_RANGE_4G, SensorQMI8658::ACC_ODR_125Hz, SensorQMI8658::LPF_MODE_0, true);
    qmi.enableAccelerometer();
  }
#if JITTER_HAS_PMU
  pmu_ok = PMU.begin(Wire, AXP2101_SLAVE_ADDRESS, IIC_SDA, IIC_SCL);
  if (pmu_ok) PMU.enableBattVoltageMeasure();
#endif

  lv_init();
  const uint32_t px = LCD_WIDTH * LCD_HEIGHT / 4;
  lv_color_t *buf1 = (lv_color_t *)heap_caps_malloc(px * sizeof(lv_color_t), MALLOC_CAP_DMA);
  lv_color_t *buf2 = (lv_color_t *)heap_caps_malloc(px * sizeof(lv_color_t), MALLOC_CAP_DMA);
  lv_disp_draw_buf_init(&draw_buf, buf1, buf2, px);

  static lv_disp_drv_t disp_drv;
  lv_disp_drv_init(&disp_drv);
  disp_drv.hor_res = LCD_WIDTH;
  disp_drv.ver_res = LCD_HEIGHT;
  disp_drv.flush_cb = my_disp_flush;
  disp_drv.draw_buf = &draw_buf;
  lv_disp_drv_register(&disp_drv);

  static lv_indev_drv_t indev_drv;
  lv_indev_drv_init(&indev_drv);
  indev_drv.type = LV_INDEV_TYPE_POINTER;
  indev_drv.read_cb = my_touchpad_read;
  lv_indev_drv_register(&indev_drv);

  const esp_timer_create_args_t targs = {.callback = &lvgl_tick, .name = "lvgl_tick"};
  esp_timer_handle_t th = NULL;
  esp_timer_create(&targs, &th);
  esp_timer_start_periodic(th, 2 * 1000);

  jitter_ui_init(wifi_scan, sys_text);
}

void loop() {
  lv_timer_handler();
  delay(5);

  static uint32_t t_rtc, t_imu, t_bat;
  uint32_t now = millis();

  if (rtc_ok && now - t_rtc >= 250) {
    t_rtc = now;
    RTC_DateTime d = rtc.getDateTime();
    jitter_ui_set_time(d.hour, d.minute, d.second, d.day, d.month, d.year);
  }
  if (imu_ok && jitter_ui_imu_active() && now - t_imu >= 40) {
    t_imu = now;
    float x, y, z;
    if (qmi.getDataReady() && qmi.getAccelerometer(x, y, z)) jitter_ui_set_imu(x, y, z);
  }
#if JITTER_HAS_PMU
  if (pmu_ok && now - t_bat >= 5000) {
    t_bat = now;
    jitter_ui_set_battery(PMU.isBatteryConnect() ? PMU.getBatteryPercent() : -1, PMU.isCharging());
  }
#endif
}
