#include "jitter_ui.h"
#include "jitter_assets.h"
#include "jitter_fonts.h"
#include <stdio.h>
#include <string.h>
#include <math.h>

// ---- Jitter-Shadow palette (from the GTK theme) ---------------------------------
#define C_BG      lv_color_hex(0x0B0B0D)
#define C_BG2     lv_color_hex(0x131316)
#define C_BG3     lv_color_hex(0x1B1B1F)
#define C_WELL    lv_color_hex(0x050506)
#define C_STEEL   lv_color_hex(0x5A5C62)
#define C_STEEL_L lv_color_hex(0x9A9CA2)
#define C_FG      lv_color_hex(0xCFCFD3)
#define C_FG_HI   lv_color_hex(0xE8E8EC)
#define C_DIM     lv_color_hex(0x8A8B90)
#define C_RED     lv_color_hex(0xD41A1A)
#define C_RED_D   lv_color_hex(0x7A0D0D)
#define C_RED_B   lv_color_hex(0xFF4646)

// Flip these if the tilt dot moves the wrong way on your board orientation
#define JITTER_IMU_FLIP_X 0
#define JITTER_IMU_FLIP_Y 0

#define F_UI   (&jb_15)
#define F_B    (&jb_15b)
#define F_BIG  (&jb_44b)

static lv_obj_t *scr_boot, *scr_home, *scr_menu, *scr_imu, *scr_wifi, *scr_sys, *scr_sd, *scr_audio;
static lv_style_t st_tile_pr, st_btn, st_btn_pr;
static jitter_wifi_scan_fn wifi_fn_;
static jitter_sys_text_fn sys_fn_;

// ---- small helpers ---------------------------------------------------------------
static void decor(lv_obj_t *o) {  // non-interactive decoration
  lv_obj_clear_flag(o, (lv_obj_flag_t)(LV_OBJ_FLAG_CLICKABLE | LV_OBJ_FLAG_SCROLLABLE));
}

static lv_obj_t *mk_screen(void) {
  lv_obj_t *s = lv_obj_create(NULL);
  lv_obj_remove_style_all(s);
  lv_obj_set_style_bg_color(s, C_BG, 0);
  lv_obj_set_style_bg_opa(s, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(s, 1, 0);
  lv_obj_set_style_border_color(s, C_STEEL, 0);
  lv_obj_set_style_border_opa(s, LV_OPA_COVER, 0);
  lv_obj_clear_flag(s, LV_OBJ_FLAG_SCROLLABLE);
  return s;
}

static lv_obj_t *mk_rect(lv_obj_t *p, int w, int h, lv_color_t c) {
  lv_obj_t *o = lv_obj_create(p);
  lv_obj_remove_style_all(o);
  lv_obj_set_size(o, w, h);
  lv_obj_set_style_bg_color(o, c, 0);
  lv_obj_set_style_bg_opa(o, LV_OPA_COVER, 0);
  decor(o);
  return o;
}

static lv_obj_t *mk_label(lv_obj_t *p, const char *txt, const lv_font_t *f, lv_color_t c) {
  lv_obj_t *l = lv_label_create(p);
  lv_obj_set_style_text_font(l, f, 0);
  lv_obj_set_style_text_color(l, c, 0);
  lv_label_set_text(l, txt);
  return l;
}

static void bracket(lv_obj_t *p, lv_align_t al, int bx, int by, uint8_t sides) {
  lv_obj_t *o = lv_obj_create(p);
  lv_obj_remove_style_all(o);
  lv_obj_set_size(o, 14, 14);
  lv_obj_set_style_border_width(o, 2, 0);
  lv_obj_set_style_border_color(o, C_RED, 0);
  lv_obj_set_style_border_opa(o, LV_OPA_COVER, 0);
  lv_obj_set_style_border_side(o, (lv_border_side_t)sides, 0);
  lv_obj_align(o, al, bx, by);
  decor(o);
}
static void brackets(lv_obj_t *p) {
  bracket(p, LV_ALIGN_TOP_LEFT, 5, 5, LV_BORDER_SIDE_LEFT | LV_BORDER_SIDE_TOP);
  bracket(p, LV_ALIGN_TOP_RIGHT, -5, 5, LV_BORDER_SIDE_RIGHT | LV_BORDER_SIDE_TOP);
  bracket(p, LV_ALIGN_BOTTOM_LEFT, 5, -5, LV_BORDER_SIDE_LEFT | LV_BORDER_SIDE_BOTTOM);
  bracket(p, LV_ALIGN_BOTTOM_RIGHT, -5, -5, LV_BORDER_SIDE_RIGHT | LV_BORDER_SIDE_BOTTOM);
}

static void goto_cb(lv_event_t *e) {
  lv_obj_t **target = (lv_obj_t **)lv_event_get_user_data(e);
  lv_scr_load(*target);
}

// Steel title bar: gradient, steel top line, dark-red bottom line (like the xfwm4 frame)
static void header(lv_obj_t *scr, const char *title, lv_obj_t **back_to) {
  lv_obj_t *h = lv_obj_create(scr);
  lv_obj_remove_style_all(h);
  lv_obj_set_size(h, 238, 30);
  lv_obj_align(h, LV_ALIGN_TOP_MID, 0, 0);
  lv_obj_set_style_bg_color(h, lv_color_hex(0x2B2B30), 0);
  lv_obj_set_style_bg_grad_color(h, lv_color_hex(0x121214), 0);
  lv_obj_set_style_bg_grad_dir(h, LV_GRAD_DIR_VER, 0);
  lv_obj_set_style_bg_opa(h, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(h, 2, 0);
  lv_obj_set_style_border_color(h, C_RED_D, 0);
  lv_obj_set_style_border_opa(h, LV_OPA_COVER, 0);
  lv_obj_set_style_border_side(h, LV_BORDER_SIDE_BOTTOM, 0);
  decor(h);
  lv_obj_t *top = mk_rect(scr, 238, 1, C_STEEL_L);
  lv_obj_align(top, LV_ALIGN_TOP_MID, 0, 0);

  lv_obj_t *t = mk_label(scr, title, F_B, C_FG_HI);
  lv_obj_align(t, LV_ALIGN_TOP_LEFT, back_to ? 40 : 12, 4);

  if (back_to) {
    lv_obj_t *b = lv_obj_create(scr);
    lv_obj_remove_style_all(b);
    lv_obj_set_size(b, 34, 30);
    lv_obj_align(b, LV_ALIGN_TOP_LEFT, 1, 0);
    lv_obj_set_style_bg_color(b, C_RED_D, LV_STATE_PRESSED);
    lv_obj_set_style_bg_opa(b, LV_OPA_COVER, LV_STATE_PRESSED);
    lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *a = mk_label(b, "<", F_B, C_RED_B);
    lv_obj_center(a);
    lv_obj_add_event_cb(b, goto_cb, LV_EVENT_CLICKED, back_to);
  }
}

// =================================================================================
//  BOOT
// =================================================================================
static lv_obj_t *boot_arc, *boot_bar, *boot_txt;
static lv_timer_t *boot_timer;
static int boot_tick;

static void boot_step(lv_timer_t *t) {
  boot_tick++;
  lv_arc_set_rotation(boot_arc, (boot_tick * 14) % 360);
  int pct = boot_tick * 100 / 60;  // ~2.4 s at 40 ms
  if (pct > 100) pct = 100;
  lv_bar_set_value(boot_bar, pct, LV_ANIM_OFF);
  const char *msg = pct < 25 ? "> INITIALIZING..." : pct < 55 ? "> MOUNTING DRIVERS..." : pct < 90 ? "> LINKING SENSORS..." : "> SYSTEMS ONLINE_";
  lv_label_set_text(boot_txt, msg);
  lv_obj_set_style_text_color(boot_txt, pct >= 90 ? C_RED_B : C_DIM, 0);
  if (boot_tick > 72) {  // brief hold at 100%
    lv_timer_del(boot_timer);
    lv_scr_load(scr_home);
  }
}

static void build_boot(void) {
  scr_boot = mk_screen();
  brackets(scr_boot);
  boot_arc = lv_arc_create(scr_boot);
  lv_obj_remove_style_all(boot_arc);
  lv_obj_set_size(boot_arc, 124, 124);
  lv_obj_align(boot_arc, LV_ALIGN_TOP_MID, 0, 6);
  lv_arc_set_bg_angles(boot_arc, 0, 0);
  lv_arc_set_angles(boot_arc, 0, 80);
  lv_obj_set_style_arc_width(boot_arc, 3, LV_PART_INDICATOR);
  lv_obj_set_style_arc_color(boot_arc, C_RED_B, LV_PART_INDICATOR);
  lv_obj_set_style_arc_opa(boot_arc, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_obj_set_style_arc_rounded(boot_arc, false, LV_PART_INDICATOR);
  decor(boot_arc);

  lv_obj_t *em = lv_img_create(scr_boot);
  lv_img_set_src(em, &img_emblem);
  lv_obj_align(em, LV_ALIGN_TOP_MID, 0, 16);
  lv_obj_t *wm = lv_img_create(scr_boot);
  lv_img_set_src(wm, &img_wordmark);
  lv_obj_align(wm, LV_ALIGN_TOP_MID, 0, 138);
  lv_obj_t *tag = mk_label(scr_boot, "BUILD. HACK. CREATE.", F_UI, C_STEEL_L);
  lv_obj_align(tag, LV_ALIGN_TOP_MID, 0, 190);

  boot_bar = lv_bar_create(scr_boot);
  lv_obj_remove_style_all(boot_bar);
  lv_obj_set_size(boot_bar, 176, 8);
  lv_obj_align(boot_bar, LV_ALIGN_TOP_MID, 0, 224);
  lv_obj_set_style_bg_opa(boot_bar, LV_OPA_TRANSP, LV_PART_MAIN);
  lv_obj_set_style_border_width(boot_bar, 1, LV_PART_MAIN);
  lv_obj_set_style_border_color(boot_bar, C_STEEL, LV_PART_MAIN);
  lv_obj_set_style_border_opa(boot_bar, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_bg_color(boot_bar, C_RED, LV_PART_INDICATOR);
  lv_obj_set_style_bg_opa(boot_bar, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_bar_set_range(boot_bar, 0, 100);
  decor(boot_bar);
  boot_txt = mk_label(scr_boot, "> INITIALIZING...", F_UI, C_DIM);
  lv_obj_align(boot_txt, LV_ALIGN_TOP_MID, 0, 240);
}

// =================================================================================
//  HOME
// =================================================================================
static lv_obj_t *home_arc, *home_time, *home_date, *home_bat, *home_prompt;
static const char *DOW[] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
static const char *MON[] = {"JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};

static int day_of_week(int y, int m, int d) {  // 0 = Sunday
  static const int t[] = {0, 3, 2, 5, 0, 3, 5, 1, 4, 6, 2, 4};
  if (m < 3) y -= 1;
  return (y + y / 4 - y / 100 + y / 400 + t[m - 1] + d) % 7;
}

static void cursor_blink(lv_timer_t *t) {
  static bool on = true;
  on = !on;
  lv_label_set_text(home_prompt, on ? "#ff4646 jitter#@5H4D0W:~$ _" : "#ff4646 jitter#@5H4D0W:~$  ");
}

static void home_gesture(lv_event_t *e) {
  if (lv_indev_get_gesture_dir(lv_indev_get_act()) == LV_DIR_TOP) lv_scr_load(scr_menu);
}

static void build_home(void) {
  scr_home = mk_screen();
  brackets(scr_home);
  lv_obj_t *l = mk_label(scr_home, "5H4D0W", F_UI, C_DIM);
  lv_obj_align(l, LV_ALIGN_TOP_LEFT, 26, 8);
  home_bat = mk_label(scr_home, "BAT --", F_UI, C_DIM);
  lv_obj_align(home_bat, LV_ALIGN_TOP_RIGHT, -26, 8);

  // outer second-hand ring + inner dotted ring + cardinal ticks
  home_arc = lv_arc_create(scr_home);
  lv_obj_remove_style_all(home_arc);
  lv_obj_set_size(home_arc, 172, 172);
  lv_obj_align(home_arc, LV_ALIGN_TOP_MID, 0, 34);
  lv_arc_set_rotation(home_arc, 270);
  lv_arc_set_bg_angles(home_arc, 0, 360);
  lv_arc_set_range(home_arc, 0, 60);
  lv_arc_set_value(home_arc, 0);
  lv_obj_set_style_arc_width(home_arc, 4, LV_PART_MAIN);
  lv_obj_set_style_arc_color(home_arc, lv_color_hex(0x2A2B30), LV_PART_MAIN);
  lv_obj_set_style_arc_opa(home_arc, LV_OPA_COVER, LV_PART_MAIN);
  lv_obj_set_style_arc_width(home_arc, 4, LV_PART_INDICATOR);
  lv_obj_set_style_arc_color(home_arc, C_RED, LV_PART_INDICATOR);
  lv_obj_set_style_arc_opa(home_arc, LV_OPA_COVER, LV_PART_INDICATOR);
  lv_obj_set_style_arc_rounded(home_arc, false, LV_PART_INDICATOR);
  lv_obj_set_style_arc_rounded(home_arc, false, LV_PART_MAIN);
  decor(home_arc);

  lv_obj_t *in = lv_obj_create(scr_home);
  lv_obj_remove_style_all(in);
  lv_obj_set_size(in, 148, 148);
  lv_obj_align(in, LV_ALIGN_TOP_MID, 0, 46);
  lv_obj_set_style_radius(in, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_border_width(in, 1, 0);
  lv_obj_set_style_border_color(in, C_RED_D, 0);
  lv_obj_set_style_border_opa(in, LV_OPA_COVER, 0);
  decor(in);
  lv_obj_t *tk;
  tk = mk_rect(scr_home, 4, 12, C_RED_B); lv_obj_align(tk, LV_ALIGN_TOP_MID, 0, 30);
  tk = mk_rect(scr_home, 12, 4, C_RED_B); lv_obj_align(tk, LV_ALIGN_TOP_MID, -92, 118);
  tk = mk_rect(scr_home, 12, 4, C_RED_B); lv_obj_align(tk, LV_ALIGN_TOP_MID, 92, 118);

  home_time = mk_label(scr_home, "09:41", F_BIG, C_FG_HI);
  lv_obj_align(home_time, LV_ALIGN_TOP_MID, 0, 80);
  home_date = mk_label(scr_home, "TUE 24 NOV", F_UI, C_STEEL_L);
  lv_obj_align(home_date, LV_ALIGN_TOP_MID, 0, 142);

  home_prompt = mk_label(scr_home, "#ff4646 jitter#@5H4D0W:~$ _", F_UI, C_FG);
  lv_label_set_recolor(home_prompt, true);
  lv_obj_align(home_prompt, LV_ALIGN_TOP_LEFT, 24, 214);
  lv_obj_t *t1 = mk_label(scr_home, "> MIND FOCUSED.", F_UI, C_DIM);
  lv_obj_align(t1, LV_ALIGN_TOP_LEFT, 24, 234);
  lv_obj_t *t2 = mk_label(scr_home, "> NO DISTRACTIONS.", F_UI, C_FG);
  lv_obj_align(t2, LV_ALIGN_TOP_LEFT, 24, 250);
  lv_obj_t *bar = mk_rect(scr_home, 60, 3, C_RED);
  lv_obj_align(bar, LV_ALIGN_BOTTOM_MID, 0, -4);

  lv_obj_add_event_cb(scr_home, goto_cb, LV_EVENT_CLICKED, &scr_menu);
  lv_obj_add_event_cb(scr_home, home_gesture, LV_EVENT_GESTURE, NULL);
  lv_timer_create(cursor_blink, 500, NULL);
}

// =================================================================================
//  MENU
// =================================================================================
static void build_menu(void) {
  scr_menu = mk_screen();
  header(scr_menu, "JITTER // MENU", &scr_home);
  struct Item { const lv_img_dsc_t *ic; const char *name; lv_obj_t **target; };
  const Item items[6] = {
    {&ic_clock, "CLOCK", &scr_home}, {&ic_imu, "IMU", &scr_imu},
    {&ic_wifi, "WI-FI", &scr_wifi},  {&ic_sd, "SD CARD", &scr_sd},
    {&ic_audio, "AUDIO", &scr_audio}, {&ic_system, "SYSTEM", &scr_sys}};
  for (int i = 0; i < 6; i++) {
    lv_obj_t *t = lv_obj_create(scr_menu);
    lv_obj_remove_style_all(t);
    lv_obj_set_size(t, 112, 74);
    lv_obj_align(t, LV_ALIGN_TOP_LEFT, 5 + (i % 2) * 116, 36 + (i / 2) * 78);
    lv_obj_set_style_border_width(t, 1, 0);
    lv_obj_set_style_border_color(t, C_BG, 0);
    lv_obj_set_style_border_opa(t, LV_OPA_COVER, 0);
    lv_obj_add_style(t, &st_tile_pr, LV_STATE_PRESSED);
    lv_obj_clear_flag(t, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t *im = lv_img_create(t);
    lv_img_set_src(im, items[i].ic);
    lv_obj_align(im, LV_ALIGN_TOP_MID, 0, 2);
    lv_obj_clear_flag(im, LV_OBJ_FLAG_CLICKABLE);
    lv_obj_t *lb = mk_label(t, items[i].name, i == 0 ? F_B : F_UI, i == 0 ? C_RED_B : C_FG);
    lv_obj_align(lb, LV_ALIGN_BOTTOM_MID, 0, -1);
    lv_obj_add_event_cb(t, goto_cb, LV_EVENT_CLICKED, (void *)items[i].target);
  }
}

// =================================================================================
//  IMU
// =================================================================================
static lv_obj_t *imu_dot, *imu_bar[3], *imu_val[3], *imu_tilt;
static float imu_sx, imu_sy;

static void build_imu(void) {
  scr_imu = mk_screen();
  header(scr_imu, "IMU // QMI8658", &scr_menu);
  lv_obj_t *ret = lv_obj_create(scr_imu);
  lv_obj_remove_style_all(ret);
  lv_obj_set_size(ret, 108, 108);
  lv_obj_align(ret, LV_ALIGN_TOP_MID, 0, 40);
  lv_obj_set_style_radius(ret, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(ret, C_WELL, 0);
  lv_obj_set_style_bg_opa(ret, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(ret, 1, 0);
  lv_obj_set_style_border_color(ret, C_STEEL, 0);
  lv_obj_set_style_border_opa(ret, LV_OPA_COVER, 0);
  decor(ret);
  lv_obj_t *h = mk_rect(ret, 106, 1, C_STEEL); lv_obj_align(h, LV_ALIGN_CENTER, 0, 0);
  lv_obj_t *v = mk_rect(ret, 1, 106, C_STEEL); lv_obj_align(v, LV_ALIGN_CENTER, 0, 0);
  lv_obj_t *mid = lv_obj_create(ret);
  lv_obj_remove_style_all(mid);
  lv_obj_set_size(mid, 36, 36);
  lv_obj_align(mid, LV_ALIGN_CENTER, 0, 0);
  lv_obj_set_style_radius(mid, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_border_width(mid, 1, 0);
  lv_obj_set_style_border_color(mid, C_RED_D, 0);
  lv_obj_set_style_border_opa(mid, LV_OPA_COVER, 0);
  decor(mid);
  imu_dot = lv_obj_create(ret);
  lv_obj_remove_style_all(imu_dot);
  lv_obj_set_size(imu_dot, 14, 14);
  lv_obj_set_style_radius(imu_dot, LV_RADIUS_CIRCLE, 0);
  lv_obj_set_style_bg_color(imu_dot, C_RED, 0);
  lv_obj_set_style_bg_opa(imu_dot, LV_OPA_COVER, 0);
  lv_obj_set_style_border_width(imu_dot, 1, 0);
  lv_obj_set_style_border_color(imu_dot, C_RED_B, 0);
  lv_obj_set_style_border_opa(imu_dot, LV_OPA_COVER, 0);
  lv_obj_align(imu_dot, LV_ALIGN_CENTER, 0, 0);
  decor(imu_dot);

  const char *ax[3] = {"X", "Y", "Z"};
  for (int i = 0; i < 3; i++) {
    int y = 156 + i * 28;
    lv_obj_t *n = mk_label(scr_imu, ax[i], F_UI, C_RED_B);
    lv_obj_align(n, LV_ALIGN_TOP_LEFT, 16, y);
    imu_val[i] = mk_label(scr_imu, "+0.00 g", F_UI, C_FG);
    lv_obj_align(imu_val[i], LV_ALIGN_TOP_RIGHT, -16, y);
    imu_bar[i] = lv_bar_create(scr_imu);
    lv_obj_remove_style_all(imu_bar[i]);
    lv_obj_set_size(imu_bar[i], 208, 8);
    lv_obj_align(imu_bar[i], LV_ALIGN_TOP_MID, 0, y + 17);
    lv_bar_set_mode(imu_bar[i], LV_BAR_MODE_SYMMETRICAL);
    lv_bar_set_range(imu_bar[i], -2000, 2000);
    lv_obj_set_style_bg_color(imu_bar[i], C_WELL, LV_PART_MAIN);
    lv_obj_set_style_bg_opa(imu_bar[i], LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_border_width(imu_bar[i], 1, LV_PART_MAIN);
    lv_obj_set_style_border_color(imu_bar[i], C_STEEL, LV_PART_MAIN);
    lv_obj_set_style_border_opa(imu_bar[i], LV_OPA_COVER, LV_PART_MAIN);
    lv_obj_set_style_bg_color(imu_bar[i], i == 2 ? C_STEEL_L : C_RED, LV_PART_INDICATOR);
    lv_obj_set_style_bg_opa(imu_bar[i], LV_OPA_COVER, LV_PART_INDICATOR);
    decor(imu_bar[i]);
  }
  imu_tilt = mk_label(scr_imu, "ROLL +00 PITCH +00", F_UI, C_DIM);
  lv_obj_align(imu_tilt, LV_ALIGN_BOTTOM_MID, 0, -6);
}

bool jitter_ui_imu_active(void) { return lv_scr_act() == scr_imu; }

void jitter_ui_set_imu(float ax, float ay, float az) {
  if (!scr_imu || lv_scr_act() != scr_imu) return;
  float v[3] = {ax, ay, az};
  char buf[16];
  for (int i = 0; i < 3; i++) {
    lv_bar_set_value(imu_bar[i], (int)(v[i] * 1000), LV_ANIM_OFF);
    snprintf(buf, sizeof buf, "%+.2f g", v[i]);
    lv_label_set_text(imu_val[i], buf);
  }
  float tx = ax > 1 ? 1 : ax < -1 ? -1 : ax, ty = ay > 1 ? 1 : ay < -1 ? -1 : ay;
  if (JITTER_IMU_FLIP_X) tx = -tx;
  if (JITTER_IMU_FLIP_Y) ty = -ty;
  imu_sx += (tx - imu_sx) * 0.35f;  // smooth the dot
  imu_sy += (ty - imu_sy) * 0.35f;
  lv_obj_align(imu_dot, LV_ALIGN_CENTER, (int)(imu_sx * 44), (int)(imu_sy * 44));
  int roll = (int)(atan2f(ay, az) * 57.2958f);
  int pitch = (int)(atan2f(-ax, sqrtf(ay * ay + az * az)) * 57.2958f);
  char tl[32];
  snprintf(tl, sizeof tl, "ROLL %+03d PITCH %+03d", roll, pitch);
  lv_label_set_text(imu_tilt, tl);
}

// =================================================================================
//  WI-FI
// =================================================================================
static lv_obj_t *wifi_list, *wifi_status;

static void wifi_scan_cb(lv_event_t *e) {
  if (!wifi_fn_) { lv_label_set_text(wifi_status, "> NO RADIO HOOK"); return; }
  lv_label_set_text(wifi_status, "> SCANNING...");
  lv_label_set_text(wifi_list, "");
  lv_refr_now(NULL);
  static char ssid[8][33];
  int rssi[8];
  int n = wifi_fn_(ssid, rssi, 8);
  static char txt[8 * 40];
  txt[0] = 0;
  for (int i = 0; i < n; i++) {
    char name[15];
    snprintf(name, sizeof name, "%.14s", ssid[i][0] ? ssid[i] : "(hidden)");
    char line[40];
    snprintf(line, sizeof line, "#%s %d# %s\n", rssi[i] > -60 ? "ff4646" : "8A8B90", rssi[i], name);
    strncat(txt, line, sizeof txt - strlen(txt) - 1);
  }
  lv_label_set_text(wifi_list, txt);
  char st[24];
  snprintf(st, sizeof st, "> %d NETWORKS", n);
  lv_label_set_text(wifi_status, st);
}

static void build_wifi(void) {
  scr_wifi = mk_screen();
  header(scr_wifi, "WI-FI // SCAN", &scr_menu);
  lv_obj_t *b = lv_obj_create(scr_wifi);
  lv_obj_remove_style_all(b);
  lv_obj_set_size(b, 120, 28);
  lv_obj_align(b, LV_ALIGN_TOP_MID, 0, 40);
  lv_obj_add_style(b, &st_btn, 0);
  lv_obj_add_style(b, &st_btn_pr, LV_STATE_PRESSED);
  lv_obj_clear_flag(b, LV_OBJ_FLAG_SCROLLABLE);
  lv_obj_t *t = mk_label(b, "SCAN", F_B, C_FG_HI);
  lv_obj_center(t);
  lv_obj_add_event_cb(b, wifi_scan_cb, LV_EVENT_CLICKED, NULL);
  wifi_list = mk_label(scr_wifi, "", F_UI, C_FG);
  lv_label_set_recolor(wifi_list, true);
  lv_obj_set_width(wifi_list, 214);
  lv_obj_align(wifi_list, LV_ALIGN_TOP_LEFT, 14, 78);
  wifi_status = mk_label(scr_wifi, "> TAP SCAN_", F_UI, C_DIM);
  lv_obj_align(wifi_status, LV_ALIGN_BOTTOM_LEFT, 14, -6);
}

// =================================================================================
//  SYSTEM + stubs
// =================================================================================
static lv_obj_t *sys_text;

static void sys_refresh(lv_timer_t *t) {
  if (lv_scr_act() != scr_sys || !sys_fn_) return;
  static char buf[160];
  sys_fn_(buf, sizeof buf);
  lv_label_set_text(sys_text, buf);
}

static void build_sys(void) {
  scr_sys = mk_screen();
  header(scr_sys, "SYSTEM // INFO", &scr_menu);
  sys_text = mk_label(scr_sys, "> NO DATA HOOK", F_UI, C_FG);
  lv_obj_set_width(sys_text, 214);
  lv_obj_align(sys_text, LV_ALIGN_TOP_LEFT, 14, 44);
  lv_obj_set_style_text_line_space(sys_text, 6, 0);
  lv_timer_create(sys_refresh, 1000, NULL);
}

static lv_obj_t *build_stub(const char *title, const lv_img_dsc_t *ic) {
  lv_obj_t *s = mk_screen();
  header(s, title, &scr_menu);
  lv_obj_t *im = lv_img_create(s);
  lv_img_set_src(im, ic);
  lv_obj_align(im, LV_ALIGN_TOP_MID, 0, 70);
  lv_obj_t *a = mk_label(s, "MODULE OFFLINE", F_B, C_RED_B);
  lv_obj_align(a, LV_ALIGN_TOP_MID, 0, 140);
  lv_obj_t *b = mk_label(s, "> NOT IMPLEMENTED_", F_UI, C_DIM);
  lv_obj_align(b, LV_ALIGN_TOP_MID, 0, 164);
  return s;
}

// =================================================================================
//  public API
// =================================================================================
void jitter_ui_init(jitter_wifi_scan_fn wifi_fn, jitter_sys_text_fn sys_fn) {
  wifi_fn_ = wifi_fn;
  sys_fn_ = sys_fn;

  lv_style_init(&st_tile_pr);
  lv_style_set_bg_color(&st_tile_pr, lv_color_hex(0x1D0808));
  lv_style_set_bg_opa(&st_tile_pr, LV_OPA_COVER);
  lv_style_set_border_color(&st_tile_pr, C_RED);

  lv_style_init(&st_btn);  // GTK-style steel button
  lv_style_set_bg_color(&st_btn, lv_color_hex(0x3A3B40));
  lv_style_set_bg_grad_color(&st_btn, lv_color_hex(0x222327));
  lv_style_set_bg_grad_dir(&st_btn, LV_GRAD_DIR_VER);
  lv_style_set_bg_opa(&st_btn, LV_OPA_COVER);
  lv_style_set_border_width(&st_btn, 1);
  lv_style_set_border_color(&st_btn, C_STEEL_L);
  lv_style_set_border_opa(&st_btn, LV_OPA_COVER);
  lv_style_init(&st_btn_pr);
  lv_style_set_bg_color(&st_btn_pr, lv_color_hex(0xA11818));
  lv_style_set_bg_grad_color(&st_btn_pr, lv_color_hex(0x5C0909));
  lv_style_set_border_color(&st_btn_pr, lv_color_hex(0xE45A5A));

  scr_home = scr_menu = scr_imu = scr_wifi = scr_sys = scr_sd = scr_audio = NULL;
  build_boot();
  build_home();
  build_imu();
  build_wifi();
  build_sys();
  scr_sd = build_stub("SD // STORAGE", &ic_sd);
  scr_audio = build_stub("AUDIO // CODEC", &ic_audio);
  build_menu();
  lv_scr_load(scr_boot);
  boot_timer = lv_timer_create(boot_step, 40, NULL);
}

void jitter_ui_set_time(int h, int m, int s, int day, int mon, int year) {
  if (!scr_home || lv_scr_act() != scr_home) return;
  static int ls = -1;
  if (s == ls) return;
  ls = s;
  char b[24];
  snprintf(b, sizeof b, "%02d:%02d", h, m);
  lv_label_set_text(home_time, b);
  snprintf(b, sizeof b, "%s %02d %s", DOW[day_of_week(year, mon, day)], day, MON[(mon - 1) % 12]);
  lv_label_set_text(home_date, b);
  lv_arc_set_value(home_arc, s == 0 ? 60 : s);
}

void jitter_ui_set_battery(int pct, bool charging) {
  if (!home_bat) return;
  char b[16];
  if (pct < 0) snprintf(b, sizeof b, "BAT --");
  else snprintf(b, sizeof b, "%s %d%%", charging ? "CHG" : "BAT", pct);
  lv_label_set_text(home_bat, b);
  lv_obj_set_style_text_color(home_bat, pct >= 0 && pct < 20 && !charging ? C_RED_B : C_DIM, 0);
}
