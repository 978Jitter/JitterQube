#pragma once
// JitterOS UI - pure LVGL 8.4, no hardware access. Sized for 240x284.
#include <lvgl.h>
#include <stddef.h>

// Hardware hooks supplied by the sketch (either may be NULL)
typedef int  (*jitter_wifi_scan_fn)(char ssid[][33], int *rssi, int max);  // returns count
typedef void (*jitter_sys_text_fn)(char *buf, size_t len);                 // fills multi-line text

void jitter_ui_init(jitter_wifi_scan_fn wifi_fn, jitter_sys_text_fn sys_fn);
void jitter_ui_set_time(int h, int m, int s, int day, int mon, int year);
void jitter_ui_set_battery(int pct, bool charging);   // pct < 0 = unknown
void jitter_ui_set_imu(float ax, float ay, float az); // in g
bool jitter_ui_imu_active(void);                      // true while IMU screen is showing (so the sketch can skip reads)
