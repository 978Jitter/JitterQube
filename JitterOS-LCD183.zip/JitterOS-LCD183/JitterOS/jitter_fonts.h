#pragma once
#include <lvgl.h>
#ifdef __cplusplus
extern "C" {
#endif
extern const lv_font_t jb_15;  /* line 21px, advance 9.0px, 3959 bytes */
extern const lv_font_t jb_15b;  /* line 21px, advance 9.0px, 3674 bytes */
extern const lv_font_t jb_44b;  /* line 59px, advance 26.4px, 3601 bytes */
#ifdef __cplusplus
}
#endif
