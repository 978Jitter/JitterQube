#!/bin/bash
# Usage: sim/build.sh <path to lvgl library dir (the one containing lvgl.h)>
# Builds the real UI against LVGL on your desktop and writes out/*.png screenshots.
set -e
LVGL=${1:?need lvgl dir}; HERE=$(cd "$(dirname "$0")" && pwd); ROOT=$HERE/..; B=${TMPDIR:-/tmp}/jitter-sim-build; mkdir -p $B $HERE/out
INC="-DLV_CONF_INCLUDE_SIMPLE -I$ROOT -I$LVGL -I$LVGL/src -I$ROOT/JitterOS"
if [ ! -f $B/lvgl.a ]; then
  find $LVGL/src -name '*.c' | xargs -P8 -I{} sh -c 'gcc -O1 -c '"$INC"' {} -o '$B'/$(echo {} | md5sum | cut -c1-12).o'
  ar rcs $B/lvgl.a $B/*.o
fi
g++ -O1 $INC -x c++ $ROOT/JitterOS/jitter_ui.cpp $ROOT/JitterOS/jitter_assets.cpp $ROOT/JitterOS/jitter_fonts.cpp $HERE/sim_main.cpp -x none $B/lvgl.a -lm -o $B/sim
(cd $HERE && $B/sim)
python3 - <<PY
import numpy as np, glob, os
from PIL import Image
for f in sorted(glob.glob("$HERE/out/*.raw")):
    a=np.fromfile(f,dtype=np.uint16).reshape(284,240)
    r=((a>>11)&31)*255//31; g=((a>>5)&63)*255//63; b=(a&31)*255//31
    Image.fromarray(np.stack([r,g,b],-1).astype('uint8')).save(f[:-4]+".png")
PY
