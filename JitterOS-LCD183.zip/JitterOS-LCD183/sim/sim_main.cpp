// Desktop simulator: runs the real jitter_ui.cpp on a fake 240x284 display and dumps RGB565 frames.
#include <lvgl.h>
#include <stdio.h>
#include <string.h>
#include "../JitterOS/jitter_ui.h"

#define W 240
#define H 284
static uint16_t fb[W * H];
static lv_color_t buf1[W * H];
static int tx, ty; static bool tp;

static void flush(lv_disp_drv_t *d, const lv_area_t *a, lv_color_t *c) {
  for (int y = a->y1; y <= a->y2; y++)
    for (int x = a->x1; x <= a->x2; x++) fb[y * W + x] = c++->full;
  lv_disp_flush_ready(d);
}
static void touch(lv_indev_drv_t *d, lv_indev_data_t *data) {
  data->state = tp ? LV_INDEV_STATE_PR : LV_INDEV_STATE_REL; data->point.x = tx; data->point.y = ty;
}
static void adv(int ms) { for (int i = 0; i < ms; i += 5) { lv_tick_inc(5); lv_timer_handler(); } }
static void click(int x, int y) { tx = x; ty = y; tp = true; adv(60); tp = false; adv(80); }
static void dump(const char *name) {
  adv(60); char p[128]; snprintf(p, sizeof p, "out/%s.raw", name);
  FILE *f = fopen(p, "wb"); fwrite(fb, 2, W * H, f); fclose(f); printf("dumped %s\n", name);
}
static int fake_scan(char ssid[][33], int *rssi, int max) {
  const char *n[] = {"JitterNet_5G", "5H4D0W-LAB", "xfinitywifi", "NETGEAR42", "HomeBase"}; int r[] = {-48, -57, -71, -78, -84};
  for (int i = 0; i < 5; i++) { strcpy(ssid[i], n[i]); rssi[i] = r[i]; } return 5;
}
static void fake_sys(char *b, size_t l) {
  snprintf(b, l, "CHIP  ESP32-S3\nCPU   240 MHz\nHEAP  187 KB\nPSRAM 7.9 MB\nUP    00:12:34\nBATT  87%%");
}
int main() {
  lv_init();
  static lv_disp_draw_buf_t db; lv_disp_draw_buf_init(&db, buf1, NULL, W * H);
  static lv_disp_drv_t dd; lv_disp_drv_init(&dd); dd.hor_res = W; dd.ver_res = H; dd.flush_cb = flush; dd.draw_buf = &db; lv_disp_drv_register(&dd);
  static lv_indev_drv_t id; lv_indev_drv_init(&id); id.type = LV_INDEV_TYPE_POINTER; id.read_cb = touch; lv_indev_drv_register(&id);
  jitter_ui_init(fake_scan, fake_sys);
  adv(1300); dump("1_boot");
  adv(2200);
  jitter_ui_set_battery(87, false); jitter_ui_set_time(9, 41, 37, 24, 11, 2026); dump("2_home");
  click(120, 100); dump("3_menu");
  click(170, 70);  // IMU tile
  for (int i = 0; i < 20; i++) { jitter_ui_set_imu(0.31f, -0.22f, 0.91f); adv(20); }
  dump("4_imu");
  click(15, 15);   // back
  click(60, 150);  // wifi tile
  click(120, 54);  // scan
  dump("5_wifi");
  click(15, 15); click(170, 230); adv(1100); dump("6_system");
  click(15, 15); click(170, 150); dump("7_sd");
  return 0;
}
